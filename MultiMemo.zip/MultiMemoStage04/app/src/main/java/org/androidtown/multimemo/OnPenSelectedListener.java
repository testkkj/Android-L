package org.androidtown.multimemo;

public interface OnPenSelectedListener { //펜 굵기 선택 리스너

	//펜을 선택하면 호출
	public void onPenSelected(int pen);
}
