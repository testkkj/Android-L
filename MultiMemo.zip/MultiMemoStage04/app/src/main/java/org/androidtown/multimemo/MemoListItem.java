package org.androidtown.multimemo;

public class MemoListItem {

	private String[] mData; //데이터 배열
	private String mId;   // item ID
	private boolean mSelectable = true; //항목을 선택할 수 있는 경우

	// 아이콘 및 데이터 배열 초기화
	public MemoListItem(String itemId, String[] obj) {
		mId = itemId;
		mData = obj;
	}

	public MemoListItem(String memoId, String memoDate, String memoText,
			String id_handwriting, String uri_handwriting,
			String id_photo, String uri_photo,
			String id_video, String uri_video,
			String id_voice, String uri_voice
			)
	{
		mId = memoId;
		mData = new String[10];
		mData[0] = memoDate;
		mData[1] = memoText;
		mData[2] = id_handwriting;
		mData[3] = uri_handwriting;
		mData[4] = id_photo;
		mData[5] = uri_photo;
		mData[6] = id_video;
		mData[7] = uri_video;
		mData[8] = id_voice;
		mData[9] = uri_voice;
	}

	public boolean isSelectable() {
		return mSelectable;
	}

	public void setSelectable(boolean selectable) {
		mSelectable = selectable;
	}

	public String getId() {
		return mId;
	}

	public void setId(String itemId) {
		mId = itemId;
	}

	public String[] getData() {
		return mData;
	}

	public String getData(int index) {
		if (mData == null || index >= mData.length) {
			return null;
		}

		return mData[index];
	}

	public void setData(String[] obj) {
		mData = obj;
	}

}
