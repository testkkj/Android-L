package org.androidtown.multimemo.db;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import org.androidtown.multimemo.BasicInfo;

//메모 데이터베이스
public class MemoDatabase {

	public static final String TAG = "MemoDatabase";

	private static MemoDatabase database; //싱글톤 인스턴스

	public static String TABLE_MEMO = "MEMO"; //MEMO 테이블

	public static String TABLE_PHOTO = "PHOTO"; //PHOTO 테이블

	public static String TABLE_VIDEO = "VIDEO"; //VIDEO 테이블

	public static String TABLE_VOICE = "VOICE"; //VOICE 테이블

	public static String TABLE_HANDWRITING = "HANDWRITING";//HANDWRITING 테이블

	public static int DATABASE_VERSION = 1;//데이터베이스 버전

    private DatabaseHelper dbHelper;//헬퍼클래스 정의

    private SQLiteDatabase db;//SQLiteDatabase 인스턴스

    private Context context;

	//생성자
	private MemoDatabase(Context context) {
		this.context = context;
	}

	//인스턴스 가져오기
	public static MemoDatabase getInstance(Context context) {
		if (database == null) {
			database = new MemoDatabase(context);
		}
		return database;
	}

	//데이터베이스 열기
    public boolean open() {
    	println("opening database [" + BasicInfo.DATABASE_NAME + "].");
    	dbHelper = new DatabaseHelper(context);
    	db = dbHelper.getWritableDatabase();
    	return true;
    }

	//데이터베이스 닫기
    public void close() {
    	println("closing database [" + BasicInfo.DATABASE_NAME + "].");
    	db.close();
    	database = null;
    }

	//SELECT 명령어를 사용하여 쿼리를 실행하려면 rawQuery()를 사용한다
	//쿼리결과는 Cursor객체로 반환되며 Cursor객체는 쿼리에 의하여 생성된 행들을 가리킴
	//Cursor는 DB에서 결과를 순회하고 데이터를 읽는데 사용된다
    public Cursor rawQuery(String SQL) {
		println("\nexecuteQuery called.\n");
		Cursor c1 = null;
		try {              //rawQuery(): SQL 쿼리를 실행
			c1 = db.rawQuery(SQL, null);
			println("cursor count : " + c1.getCount());
		} catch(Exception ex) {
    		Log.e(TAG, "Exception in executeQuery", ex);
    	}
		return c1;
	}
     //SELECT 명령을 제외한 모든 SQL문장 실행. ex)CREATE TABLE, DELETE, INSERT 등
    public boolean execSQL(String SQL) {
		println("\nexecute called.\n");

		try {
			Log.d(TAG, "SQL : " + SQL);
			db.execSQL(SQL);
	    } catch(Exception ex) {
			Log.e(TAG, "Exception in executeQuery", ex);
			return false;
		}

		return true;
	}

	//헬퍼클래스 DatabaseHelper
	//데이터베이스 이름과 버전정보를 이용해 상위 클래스의 생성자 호출
    private class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context, BasicInfo.DATABASE_NAME, null, DATABASE_VERSION);
        }

        public void onCreate(SQLiteDatabase db) {
        	println("creating database [" + BasicInfo.DATABASE_NAME + "].");
        	// TABLE_MEMO
        	println("creating table [" + TABLE_MEMO + "].");
        	// 기존 테이블 삭제
        	String DROP_SQL = "drop table if exists " + TABLE_MEMO;
        	try {
        		db.execSQL(DROP_SQL);
        	} catch(Exception ex) {
        		Log.e(TAG, "Exception in DROP_SQL", ex);
        	}

        	// 테이블 만들기 - TABLE_MEMO
			// 만들어진 테이블에 저장된 데이터를 조회하여 (MultiMemoActivity)리스트뷰에 보여주게 됨
        	String CREATE_SQL = "create table " + TABLE_MEMO + "("
		        			+ "  _id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
		        			+ "  INPUT_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP, "//메모 쓴 일시
		        			+ "  CONTENT_TEXT TEXT DEFAULT '', "//텍스트 메모 저장
		        			+ "  ID_PHOTO INTEGER, "  //사진이미지 ID값 저장
		        			+ "  ID_VIDEO INTEGER, "  //동영상파일 ID값 저장
		        			+ "  ID_VOICE INTEGER, "  //음성파일 ID값 저장
		        			+ "  ID_HANDWRITING INTEGER, "  //손글씨 이미지 ID값 저장
		        			+ "  CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
		        			+ ")";
            try {
            	db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_SQL", ex);
        	}

			// TABLE_PHOTO
			println("creating table [" + TABLE_PHOTO + "].");
			DROP_SQL = "drop table if exists " + TABLE_PHOTO;
			try {
				db.execSQL(DROP_SQL);
			} catch(Exception ex) {
				Log.e(TAG, "Exception in DROP_SQL", ex);
			}
			// 테이블 만들기 - TABLE_PHOTO
        	CREATE_SQL = "create table " + TABLE_PHOTO + "("
		        			+ "  _id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
		        			+ "  URI TEXT, "  //URI 필드에는 사진파일의 위치가 저장됨
		        			+ "  CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
		        			+ ")";
            try {
            	db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_SQL", ex);
        	}

            // create index
        	String CREATE_INDEX_SQL = "create index " + TABLE_PHOTO + "_IDX ON " + TABLE_PHOTO + "("
		        			+ "URI"
		        			+ ")";
            try {
            	db.execSQL(CREATE_INDEX_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_INDEX_SQL", ex);
        	}

            // TABLE_VIDEO
        	println("creating table [" + TABLE_VIDEO + "].");
        	DROP_SQL = "drop table if exists " + TABLE_VIDEO;
        	try {
        		db.execSQL(DROP_SQL);
        	} catch(Exception ex) {
        		Log.e(TAG, "Exception in DROP_SQL", ex);
        	}
			// 테이블 만들기 - TABLE_VIDEO
        	CREATE_SQL = "create table " + TABLE_VIDEO + "("
		        			+ "  _id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
		        			+ "  URI TEXT, "
		        			+ "  CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
		        			+ ")";
            try {
            	db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_SQL", ex);
        	}

            // create index
        	CREATE_INDEX_SQL = "create index " + TABLE_VIDEO + "_IDX ON " + TABLE_VIDEO + "("
		        			+ "URI"
		        			+ ")";
            try {
            	db.execSQL(CREATE_INDEX_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_INDEX_SQL", ex);
        	}

            // TABLE_VOICE
        	println("creating table [" + TABLE_VOICE + "].");
        	DROP_SQL = "drop table if exists " + TABLE_VOICE;
        	try {
        		db.execSQL(DROP_SQL);
        	} catch(Exception ex) {
        		Log.e(TAG, "Exception in DROP_SQL", ex);
        	}

			// 테이블 만들기 - TABLE_VOICE
        	CREATE_SQL = "create table " + TABLE_VOICE + "("
		        			+ "  _id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
		        			+ "  URI TEXT, "
		        			+ "  CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
		        			+ ")";
            try {
            	db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_SQL", ex);
        	}

            // create index
        	CREATE_INDEX_SQL = "create index " + TABLE_VOICE + "_IDX ON " + TABLE_VOICE + "("
		        			+ "URI"
		        			+ ")";
            try {
            	db.execSQL(CREATE_INDEX_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_INDEX_SQL", ex);
        	}

            // TABLE_HANDWRITING
        	println("creating table [" + TABLE_HANDWRITING + "].");
        	DROP_SQL = "drop table if exists " + TABLE_HANDWRITING;
        	try {
        		db.execSQL(DROP_SQL);
        	} catch(Exception ex) {
        		Log.e(TAG, "Exception in DROP_SQL", ex);
        	}

			// 테이블 만들기 - TABLE_HANDWRITING
        	CREATE_SQL = "create table " + TABLE_HANDWRITING + "("
		        			+ "  _id INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT, "
		        			+ "  URI TEXT, "
		        			+ "  CREATE_DATE TIMESTAMP DEFAULT CURRENT_TIMESTAMP "
		        			+ ")";
            try {
            	db.execSQL(CREATE_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_SQL", ex);
        	}

            // create index
        	CREATE_INDEX_SQL = "create index " + TABLE_HANDWRITING + "_IDX ON " + TABLE_HANDWRITING + "("
		        			+ "URI"
		        			+ ")";
            try {
            	db.execSQL(CREATE_INDEX_SQL);
            } catch(Exception ex) {
        		Log.e(TAG, "Exception in CREATE_INDEX_SQL", ex);
        	}
        }

        public void onOpen(SQLiteDatabase db) {
        	println("opened database [" + BasicInfo.DATABASE_NAME + "].");
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        	println("Upgrading database from version " + oldVersion + " to " + newVersion + ".");
        }
    }

    private void println(String msg) {
    	Log.d(TAG, msg);
    }
}