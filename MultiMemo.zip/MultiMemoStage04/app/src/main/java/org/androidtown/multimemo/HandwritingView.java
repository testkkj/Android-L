package org.androidtown.multimemo;

import java.io.OutputStream;
import java.util.Stack;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

// 손글씨 뷰
public class HandwritingView extends View {
	public static final String TAG = "HandwritingView";
	Stack<Bitmap> undos = new Stack<Bitmap>(); //undo stack
	public static int maxUndos = 10;      // Maximum Undos
	public boolean changed = false;      //Changed flag

	Canvas mCanvas;
	Bitmap mBitmap;//더블버퍼링을 위한 비트맵(메모리에 그림을 그려 화면에 표시)
	final Paint mPaint;
	float lastX;  //x좌표
	float lastY;  //y좌표
    private final Path mPath = new Path();

    private float mCurveEndX;
    private float mCurveEndY;
    private int mInvalidateExtraBorder = 10;
    static final float TOUCH_TOLERANCE = 1;

    private static final boolean RENDERING_ANTIALIAS = true;//계단현상방지 선을 부드럽게 설정
    private static final boolean DITHER_FLAG = true;//dither(모호성)제거, 디더링을 활성하하는 페인트플래그
										//디더링은 요구된색상사용이 불가능할때 여러 컬러의색을 최대한 맞추는 과정
    private int mCertainColor = 0xFF000000;
    private float mStrokeWidth = 8.0f;

	public HandwritingView(Context context, AttributeSet attrs) {
		super(context, attrs);
		//새로운 페인트 객체를 만듦
		mPaint = new Paint();
		mPaint.setAntiAlias(RENDERING_ANTIALIAS);
		mPaint.setColor(mCertainColor);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeJoin(Paint.Join.ROUND);
		mPaint.setStrokeCap(Paint.Cap.ROUND);
		mPaint.setStrokeWidth(mStrokeWidth);
		mPaint.setDither(DITHER_FLAG);

		lastX = -1;
		lastY = -1;
		Log.i(TAG, "initialized.");
	}

	public HandwritingView(Context context) {
		super(context);
		//새로운 페인트 객체를 만듦
		mPaint = new Paint();
		mPaint.setAntiAlias(RENDERING_ANTIALIAS);
		mPaint.setColor(mCertainColor);
		mPaint.setStyle(Paint.Style.STROKE);
		mPaint.setStrokeJoin(Paint.Join.ROUND);
		mPaint.setStrokeCap(Paint.Cap.ROUND);
		mPaint.setStrokeWidth(mStrokeWidth);
		mPaint.setDither(DITHER_FLAG);

		lastX = -1;
		lastY = -1;
		Log.i(TAG, "initialized.");
	}

	public void clearUndo() {
		while(true) {
			Bitmap prev = undos.pop();
			if (prev == null) return;
			prev.recycle();
		}
	}

	public void saveUndo()	{
		if (mBitmap == null) return;
		while (undos.size() >= maxUndos){
			Bitmap i = (Bitmap)undos.get(undos.size()-1);
			i.recycle();
			undos.remove(i);
		}
		Bitmap img = Bitmap.createBitmap(mBitmap.getWidth(), mBitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas();
		canvas.setBitmap(img);
		canvas.drawBitmap(mBitmap, 0, 0, mPaint);
		undos.push(img);
		Log.i(TAG, "saveUndo() called.");
	}

	public void undo()	{
		Bitmap prev = null;
		try {
			prev = (Bitmap)undos.pop();
		} catch(Exception ex) {
			Log.e(TAG, "Exception : " + ex.getMessage());
		}
		if (prev != null){
			drawBackground(mCanvas);
			mCanvas.drawBitmap(prev, 0, 0, mPaint);
			invalidate();
			prev.recycle();
		}
		Log.i(TAG, "undo() called.");
	}

	public void drawBackground(Canvas canvas) {
		if (canvas != null) {
			canvas.drawColor(Color.argb(255, 255, 255, 255));
		}
	}

	//페인트 속성 업데이트
	public void updatePaintProperty(int color, int size){
		mPaint.setColor(color);
		mPaint.setStrokeWidth(size);
	}

	//새로운 이미지 만들기
	public void newImage(int width, int height) {
		Bitmap img = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas();
		canvas.setBitmap(img);
		mBitmap = img;
		mCanvas = canvas;
		drawBackground(mCanvas);
		changed = false;
		invalidate();
	}

	public Bitmap getImage() {
		return mBitmap;
	}

	public void setImage(Bitmap newImage)
	{
		changed = false;
		setImageSize(newImage.getWidth(),newImage.getHeight(),newImage);
		invalidate();
	}

	public void setImageSize(int width, int height, Bitmap newImage) {
		if (mBitmap != null){
			if (width < mBitmap.getWidth()) width = mBitmap.getWidth();
			if (height < mBitmap.getHeight()) height = mBitmap.getHeight();
		}
		if (width < 1 || height < 1) return;
		Bitmap img = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas();
		drawBackground(canvas);

		if (newImage != null) {
			canvas.setBitmap(newImage);
		}

		if (mBitmap != null) {
			mBitmap.recycle();
			mCanvas.restore();
		}

		mBitmap = img;
		mCanvas = canvas;
		clearUndo();
	}

	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		if (w > 0 && h > 0) {
			newImage(w, h);
		}
	}

	//비트맵 그리기
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (mBitmap != null) {
			canvas.drawBitmap(mBitmap, 0, 0, null);
		}
	}

	//터치 이벤트, UP, DOWN 및 MOVE 처리
	public boolean onTouchEvent(MotionEvent event) {
		int action = event.getAction();
		switch (action) {
			case MotionEvent.ACTION_UP:
				changed = true;
				Rect rect = touchUp(event, false);
				if (rect != null) {
                    invalidate(rect);
                }
		        mPath.rewind();
                return true;

			case MotionEvent.ACTION_DOWN:
				saveUndo();
				rect = touchDown(event);
				if (rect != null) {
                    invalidate(rect);
                }
				return true;

			case MotionEvent.ACTION_MOVE:
				rect = touchMove(event);
                if (rect != null) {
                    invalidate(rect);
                }
                return true;
		}
		return false;
	}

    private Rect touchDown(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        lastX = x;
        lastY = y;
        Rect mInvalidRect = new Rect();
        mPath.moveTo(x, y);
        final int border = mInvalidateExtraBorder;
        mInvalidRect.set((int) x - border, (int) y - border, (int) x + border, (int) y + border);
        mCurveEndX = x;
        mCurveEndY = y;
        mCanvas.drawPath(mPath, mPaint);
        return mInvalidRect;
    }

    private Rect touchMove(MotionEvent event) {
        Rect rect = processMove(event);
        return rect;
    }

    private Rect touchUp(MotionEvent event, boolean cancel) {
    	Rect rect = processMove(event);
        return rect;
    }

    private Rect processMove(MotionEvent event) {
    	final float x = event.getX();
        final float y = event.getY();
        final float dx = Math.abs(x - lastX);
        final float dy = Math.abs(y - lastY);
        Rect mInvalidRect = new Rect();
        if (dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE) {
            final int border = mInvalidateExtraBorder;
            mInvalidRect.set((int) mCurveEndX - border, (int) mCurveEndY - border,
                    (int) mCurveEndX + border, (int) mCurveEndY + border);
            float cX = mCurveEndX = (x + lastX) / 2;
            float cY = mCurveEndY = (y + lastY) / 2;
            mPath.quadTo(lastX, lastY, cX, cY);
			//새로운 곡선의 제어점과 결합
            mInvalidRect.union((int) lastX - border, (int) lastY - border,
                    (int) lastX + border, (int) lastY + border);

			//새로운 곡선의 종점과의 결합
            mInvalidRect.union((int) cX - border, (int) cY - border,
                    (int) cX + border, (int) cY + border);
            lastX = x;
            lastY = y;
            mCanvas.drawPath(mPath, mPaint);
        }
        return mInvalidRect;
    }
}
