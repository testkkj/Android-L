package org.androidtown.multimemo;

public interface OnColorSelectedListener { //색상 선택 리스너
	// 색상을 선택할 때 호출
	public void onColorSelected(int color);
}
