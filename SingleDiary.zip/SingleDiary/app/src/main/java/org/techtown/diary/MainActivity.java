package org.techtown.diary;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.pedro.library.AutoPermissions;
import com.pedro.library.AutoPermissionsListener;
import com.stanfy.gsonxml.GsonXml;
import com.stanfy.gsonxml.GsonXmlBuilder;
import com.stanfy.gsonxml.XmlParserCreator;

import org.techtown.diary.data.WeatherItem;
import org.techtown.diary.data.WeatherResult;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
//MainActivity- 날씨 정보 요청 클래스
public class MainActivity extends AppCompatActivity
        implements OnTabItemSelectedListener, OnRequestListener, MyApplication.OnResponseListener, AutoPermissionsListener {

    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;
    BottomNavigationView bottomNavigation;

    Location currentLocation;   //현재 위치를 담는 변수
    GPSListener gpsListener;     //위치 정보를 수신하는 변수
    int locationCount=0;        //위치 한번 확인 후 위치요청 취소하기 위한 횟수 저장 변수
    String currentWeather;
    String currentAddress;
    String currentDateString;
    Date currentDate;
    public static NoteDatabase mDatabase = null; //데이터베이스 인스턴스

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();

        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment1).commit();

        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.tab1:
                        Toast.makeText(getApplicationContext(),"첫 번째 탭 선택",Toast.LENGTH_SHORT).show();
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment1).commit();
                        return true;
                    case R.id.tab2:
                        Toast.makeText(getApplicationContext(),"두 번째 탭 선택",Toast.LENGTH_SHORT).show();
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment2).commit();
                        return true;
                    case R.id.tab3:
                        Toast.makeText(getApplicationContext(),"세 번째 탭 선택",Toast.LENGTH_SHORT).show();
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment3).commit();
                        return true;
                }
                return false;
            }
        });

        AutoPermissions.Companion.loadAllPermissions(this,101);
        setPicturePath();

        openDatabase();
    }

    public void openDatabase() {
        if (mDatabase !=null){
            mDatabase.close();
            mDatabase=null;
        }
        mDatabase=NoteDatabase.getInstance(this);
        boolean isOpen = mDatabase.open();
        if (isOpen){
            Log.d("MainActivity","NoteDatabase Open");
        }else {
            Log.d("MainActivity","NoteDatabase Not Open");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDatabase !=null){
            mDatabase.close();
            mDatabase=null;
        }
    }

    public void setPicturePath() {
        String sdcardPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        AppConstants.FOLDER_PHOTO = sdcardPath + File.separator + "photo";
    }

    @Override
    public void onTabSelected(int position) {
        if (position==0){
            bottomNavigation.setSelectedItemId(R.id.tab1);
        }else if (position==1){
            bottomNavigation.setSelectedItemId(R.id.tab2);
        }else if (position==2){
            bottomNavigation.setSelectedItemId(R.id.tab3);
        }
    }

    @Override
    public void showFragment2(Note item) {
        fragment2 = new Fragment2();
        fragment2.setItem(item);
        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragment2).commit();
    }

    @Override
    public void onRequest(String command) {      //Fragment2에서 호출
        if (command !=null){
            if (command.equals("getCurrentLocation")){
                getCurrentLocation();   // 위치확인을 위한 메서드
            }
        }
    }

    public void getCurrentLocation() {
        currentDate = new Date();
        currentDateString = AppConstants.dateFormat3.format(currentDate);
        if (fragment2 !=null){
            fragment2.setDateString(currentDateString);
        }
        // 현재 위치 요청
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            currentLocation = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (currentLocation !=null){
                double latitude = currentLocation.getLatitude();
                double longitude = currentLocation.getLongitude();
                String message = "Last Location -> Latitude : " + latitude + "\nLongitude : " + longitude;
                println(message);
                getCurrentWeather();
                getCurrentAddress();
            }

            gpsListener = new GPSListener();
            long minTime = 10000;
            float minDistance = 0;
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,minTime,minDistance, gpsListener);
            println("Current location requested");
        }catch (SecurityException e){e.printStackTrace();}
    }

    public void stopLocationService(){
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            manager.removeUpdates(gpsListener);
            println("Current location requested");
        }catch (SecurityException e){e.printStackTrace();}
    }

    public void getCurrentAddress() {  //geocoder를 이용해 현재 위치를 주소로 변환한다
        Geocoder geocoder = new Geocoder(this, Locale.getDefault()); //위치정보를 활용하기위한 구글API객체
        List<Address> addresses = null;   //주소 목록을 담기 위한 List
        try {                                                             //주소목록을 가져온다.위도, 경도, 조회갯수
            addresses = geocoder.getFromLocation(currentLocation.getLatitude(),currentLocation.getLongitude(),1);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (addresses !=null && addresses.size() >0){   //getCountryName(나라), getAdminArea(시), getLocality(구)
            Address address = addresses.get(0);         //getThoroughfare(동), getfeatureName(지번)
            currentAddress = address.getLocality() + " " + address.getSubLocality();
            String adminArea = address.getAdminArea();
            String country = address.getCountryName();
            println("Address : " + country + " " + adminArea + " " + currentAddress);
            if (fragment2 !=null){
                fragment2.setAddress(currentAddress);
            }
        }
    }

    public void getCurrentWeather() {    //grid : (지도에서 위치를 나타내기 위한)기준선망
        Map<String,Double> gridMap = GridUtil.getGrid(currentLocation.getLatitude(),currentLocation.getLongitude());
        double gridX = gridMap.get("x");                                 // getGrid : 격자번호 확인
        double gridY = gridMap.get("y");
        println("x -> " + gridX + ", y -> " + gridY);

        sendLocalWeatherReq(gridX,gridY);
    }
    //기상청 날씨 서버로 요청을 전송
    public void sendLocalWeatherReq(double gridX, double gridY) {
        String url = "http://www.kma.go.kr/wid/queryDFS.jsp";
        url += "?gridx=" + Math.round(gridX);     //주소에 포함된 gridX gridY는 날씨정보를 확인하고 싶은 지역임
        url += "&gridy=" + Math.round(gridY);     //경위도좌표가 아닌 격자번호로 표시되어있으므로 변환과정이 필요
        Map<String,String> params = new HashMap<String, String>();                // -> GridUtil 클래스 추가/ getGrid() 메소드 추가
        MyApplication.send(AppConstants.REQ_WEATHER_BY_GRID, Request.Method.GET,url,params,this);

    }

    @Override  // 응답을 받았을 때 아래 메서드 호출 --> XML응답데이터를 자바객체로 만들어준다
    public void processResponse(int requestCode, int responseCode, String response) {
        if (responseCode==200){
            if (requestCode==AppConstants.REQ_WEATHER_BY_GRID){
                //xml문서를 처음부터 끝까지 읽어들이는 중에 유효요소(태그,속성,텍스트)가 식별되면 그 이벤트를
                //파서의 외부로 전달하여 요소에 대한 처리를 수행
                //xml 문서를 파싱하는 과정에서 식별된 요소중 원하는 정보만 선별적으로 사용할수 있으므로,
                //xml문서 구조가 중요하지않은경우 메모리를 적게 사용할 수 있어 효율적임
                //XmlPullParser인터페이스는 안드로이드 SDK 내에서 기본적으로 지원하는 xml파서이다.
                XmlParserCreator parserCreator = new XmlParserCreator() {
                    @Override
                    public XmlPullParser createParser() {
                        try {
                            return XmlPullParserFactory.newInstance().newPullParser();
                            //XmlPullParser 인터페이스의 XML 파싱 기능이 구현된 클래스 생성
                        }catch (Exception e){throw new RuntimeException(e);}
                    }
                };
                GsonXml gsonXml = new GsonXmlBuilder().setXmlParserCreator(parserCreator).setSameNameLists(true).create();
                //xml은 JSON 배열과 같은 유사성이 없으므로 목록을 역직렬화하려고 할 때 약간의 모호성이 나타난다
                //이 문제를 해결하기 위해 GsonXmlbuilder의 setSameNameLists(boolean) 메소드가 있다
                //기상청의 데이터의 응답이 XML포맷으로 되어있다

                WeatherResult weather = gsonXml.fromXml(response,WeatherResult.class);
                //response에는 inputStream이 들어있다
                try {
                    Date tmDate = AppConstants.dateFormat.parse(weather.header.tm);
                    String tmDateText = AppConstants.dateFormat2.format(tmDate);
                    println("기준 시간 : " + tmDateText);

                    for (int i=0 ; i < weather.body.datas.size();i++){
                        WeatherItem item =  weather.body.datas.get(i);
                        println("#" + i + " 시간: " + item.hour + "시, " + item.day + " 일째");
                        println(" 날씨: " + item.wfKor);
                        println(" 기온: " + item.temp + " C");
                        println(" 강수확률: " + item.pop + "%");
                        println("debug 1 : " + (int)Math.round(item.ws * 10));
                        float ws = Float.valueOf(String.valueOf((int)Math.round(item.ws*10))) / 10.0f;
                        println(" 풍속: " + ws + " m/s");
                    }

                    WeatherItem item = weather.body.datas.get(0);  //<body>의 첫번째 <data seq="0">
                    currentWeather = item.wfKor;
                    if (fragment2 !=null){
                        fragment2.setWeather(item.wfKor);
                    }
                    if (locationCount >1){  //2회 후 위치 요청 서비스 중지
                        stopLocationService();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else {
                println("Unknown request code : " + requestCode);
            }
        }else {
            println("Failure response code : " + responseCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        AutoPermissions.Companion.parsePermissions(this,requestCode,permissions,this);
    }

    @Override
    public void onDenied(int i, String[] strings) { }

    @Override
    public void onGranted(int i, String[] strings) { }

    //GPSListener class 요청된 위치를 수신하기 위한 메서드
    class GPSListener implements LocationListener{
        @Override
        public void onLocationChanged(Location location) {
            currentLocation = location;
            locationCount++;
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();

            String message = "Current Location -> Latitude : " + latitude + "\nLongitude : " + longitude;
            println(message);

            getCurrentWeather();
            getCurrentAddress();  //현재 위치를 이용해서 주소를 반환
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) { }
        @Override
        public void onProviderEnabled(String s) { }
        @Override
        public void onProviderDisabled(String s) { }
    }

    public void println(String data) {
        Log.d("MainActivity", data);
    }
}
