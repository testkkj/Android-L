package org.techtown.diary.data;  // data패키지 안에는 날씨데이터 파싱을 위한 클래스로 구성

            //XML응답데이터를 WeatherResult라는 자바객체로 만듦.
public class WeatherResult {
    public WeatherHeader header;
    public WeatherBody body;
}
