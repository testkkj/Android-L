package org.techtown.diary.data;

import java.util.ArrayList;

public class GeocodeResult {

    public ArrayList<GeocodeItem> results = new ArrayList<GeocodeItem>();
    public String status;

}
