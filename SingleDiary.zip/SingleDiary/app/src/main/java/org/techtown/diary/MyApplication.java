package org.techtown.diary;
import android.app.Application;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class MyApplication extends Application {  //Application 클래스를 상속하면 어느 컴포넌트에서나 공유할수 있는 전역클래스가 된다
                                                  //컴포넌트들 사이에서 공동으로 관리할 데이터가 있을 때 사용하며, 등록은 manifest파일에
                                                  //하며, getApplicationContext() 함수로 객체에 접근할 수 있다
    private static final String TAG = "MyApplication";
    public static RequestQueue requestQueue;

    @Override
    public void onCreate() {
        super.onCreate();          //SDK버전 9 이상-> HurlStack 클래스 사용 / 미만-> HttpClientStack 사용
        if (requestQueue==null){  // 웹데이터를 불러오기 위해 Volley라이브러리 사용 / request를 보낼 queue생성
            requestQueue = Volley.newRequestQueue(getApplicationContext(),new HurlStack(){
                @Override
                protected HttpURLConnection createConnection(URL url) throws IOException {
                    HttpURLConnection connection = super.createConnection(url);
                    connection.setInstanceFollowRedirects(false);  // 리다이렉트를 따라가지 않는다
                    return connection;
                }
            });
        }
    }

    @Override
    public void onTerminate() {  //애플리케이션 객체와 모든 컴포넌트가 종료될 때 호출
        super.onTerminate();     //항상발생되지는 않지만 종료처리할때만 사용
    }

    public static interface OnResponseListener {         // 인터페이스 OnResponseListener
        public void processResponse(int requestCode, int responseCode, String response);
    }

    public static void send(final int requestCode, int requestMethod, String url, final Map<String,String> params,
                            final OnResponseListener listener){
        StringRequest request = new StringRequest(             //StringRequest를 보냄
                requestMethod, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {    //Volley에서 응답을 받는 경우 listener의 메서드 호출
                        Log.d(TAG, "Response for " + requestCode + " -> " + response);
                        if (listener != null) {
                            listener.processResponse(requestCode, 200, response);
                        }                           //send()를 호출한 쪽에서 응답결과 처리
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d(TAG, "Error for " + requestCode + " -> " + error.getMessage());
                        if (listener !=null){
                            listener.processResponse(requestCode,400,error.getMessage());
                        }
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }
        };

        request.setShouldCache(false);
                //기본적으로 Volley는 모든 요청에 대해 연결시간 초과를 5초로 설정, 시간초과가 발생할 때
                //특정 요청을 재시도하려는 논리를 구현/ (시간초과밀리초, 재시도횟수,소켓에 설정된 지수시간결정에 사용되는 승수)
        request.setRetryPolicy(new DefaultRetryPolicy(10*1000,0,
                                                  DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MyApplication.requestQueue.add(request);
        Log.d(TAG,"Request sent : " + requestCode);
        Log.d(TAG, "Request url : " + url);
    }
}
