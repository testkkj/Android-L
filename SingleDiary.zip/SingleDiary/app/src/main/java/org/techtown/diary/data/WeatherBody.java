package org.techtown.diary.data;

import java.util.ArrayList;

public class WeatherBody {
    public ArrayList<WeatherItem> datas;
}
