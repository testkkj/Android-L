package org.techtown.diary;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import androidx.annotation.Nullable;

public class NoteDatabase {
    private static final String TAG = "NoteDatabase";
    private static NoteDatabase database;
    public static String TABLE_NOTE = "NOTE";
    public static int DATABASE_VERSION=1;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;

    private NoteDatabase(Context context) {
        this.context = context;
    }

    public static NoteDatabase getInstance(Context context){
        if (database==null){
            database = new NoteDatabase(context);
        }
        return database;
    }

    public boolean open(){
        println("opening database [" + AppConstants.DATABASE_NAME + "]");
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        return true;
    }

    public void close(){
        println("closing database [" + AppConstants.DATABASE_NAME + "]");
        db.close();
        database=null;
    }

    public Cursor rawQuery(String SQL){
        println("\nexecuteQuery called.\n");
        Cursor cursor = null;
        try {
            cursor = db.rawQuery(SQL, null);
            println("cursor count : " + cursor.getCount());
        }catch (Exception ex){
            Log.e(TAG, "Exception in executeQuery",ex);
        }
        return cursor;
    }

    public boolean execSQL(String SQL){
        println("\nexecute called.\n");
        try {
            Log.d(TAG, "SQL : " + SQL);
            db.execSQL(SQL);
        }catch (Exception ex){
            Log.e(TAG, "Exception in executeQuery",ex);
            return false;
        }
        return true;
    }
    //  <---- DatabaseHelper class
    private class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(@Nullable Context context) {
            super(context, AppConstants.DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override            //새로 데이터베이스가 만들어져야하는 상태에서는 자동호출
        public void onCreate(SQLiteDatabase db) {
            println("creating database [" + AppConstants.DATABASE_NAME + "]");
            println("creating table [" + TABLE_NOTE + "]");

            String DROP_SQL = "drop table if exists " + TABLE_NOTE;
            try {
                db.execSQL(DROP_SQL);
            }catch (Exception ex){
                Log.e(TAG, "DROP_SQL ",ex);
            }
            //NOTE 테이블 생성
            String CREATE_SQL =
                    "create table " + TABLE_NOTE + "( _id integer not null primary key autoincrement, "
                            + "weather text default '', address text default '', location_x text default '', "
                            + "location_y text default '', contents text default '', mood text, "
                            + "picture text default '', create_date timestamp default current_timestamp, "
                            + "modify_date timestamp default current_timestamp )";
            try {
                db.execSQL(CREATE_SQL);
            }catch (Exception ex){
                Log.e(TAG, "CREATE_SQL ",ex);
            }

            String CREATE_INDEX_SQL = "create index " + TABLE_NOTE + "_idx on " + TABLE_NOTE + "(create_date)";
            try {
                db.execSQL(CREATE_INDEX_SQL);                 //create_date 칼럼에 인덱스를 생성
            }catch (Exception ex){                           //이 칼럼을 기준으로 메모리영역에 일종의 목차(색인)를 생성
                Log.e(TAG, "CREATE_INDEX_SQL ",ex);   //검색속도를 빠르게 함
            }
        }

        public void onOpen(SQLiteDatabase db){
            println("opened database [" + AppConstants.DATABASE_NAME + "]");
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
            println("Upgrading database from version " + oldVersion + " to " + newVersion);
        }
    }       // DatabaseHelper class  ------->

    private void println(String msg){
        Log.d(TAG,msg);
    }
}
