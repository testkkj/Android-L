package org.techtown.diary.data;

public class WeatherItem {
    public int hour;       // 시 18
    public int day;        // 일 0
    public double temp;    //온도 24.0
    public double tmx;
    public double tmn;
    public int sky;
    public int pty;
    public String wfKor;  //구름많음
    public String wfEn;
    public int pop;       //20
    public double r12;
    public double s12;
    public double ws;     //3.1
    public int wd;
    public String wdKor;
    public String wdEn;
    public int reh;
    public double r06;
    public double s06;
}
