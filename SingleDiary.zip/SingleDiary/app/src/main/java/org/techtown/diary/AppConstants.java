package org.techtown.diary;

import java.text.ChoiceFormat;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class AppConstants {
    public static final int REQ_WEATHER_BY_GRID = 102;
    public static final int REQ_PHOTO_CAPTURE = 103;
    public static final int REQ_PHOTO_SELECTION = 104;
    public static final int CONTENT_PHOTO = 105;
    public static final int CONTENT_PHOTO_EX = 106;
    public static final int MODE_INSERT = 1;
    public static final int MODE_MODIFY = 2;
    public static String FOLDER_PHOTO;

    public static final String DATABASE_NAME = "note.db";

    public static SimpleDateFormat dateFormat = new SimpleDateFormat("YYYYMMddHHmm");
    public static SimpleDateFormat dateFormat2 = new SimpleDateFormat("YYYY-MM-dd HH시");
    public static SimpleDateFormat dateFormat3 = new SimpleDateFormat("MM월 dd일");
    public static SimpleDateFormat dateFormat4 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static SimpleDateFormat dateFormat5 = new SimpleDateFormat("yyyy-MM-dd");
}
